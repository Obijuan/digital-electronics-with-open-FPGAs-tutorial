# Academia-Jedi-HW-18 Collection

[![Icestudio](https://img.shields.io/badge/collection-icestudio-blue.svg)](https://github.com/FPGAwars/icestudio)
![Version](https://img.shields.io/badge/version-v0.1.0-orange.svg)

Colección para la Academia Jedi de Hardware.

## Install

* Download the collection: [stable](https://github.com/Obijuan/Academia-Jedi-Hw/archive/v0.1.0.zip) or [development](https://github.com/Obijuan/Academia-Jedi-Hw/archive/master.zip)
* Install the collection: *Tools > Collections > Add*
* Load the collection: *Select > Collection*

## Blocks
* *Bits*
  * 0
  * 1
* *Puertas*
  * and
  * not
  * or
* *Varios*
  * *Bombeo*
    * Corazon_Hz
    * Corazon_Seg
    * *Fijos*
      * Corazon_10Hz
      * Corazon_1Hz
      * Corazon_1KHz
      * Corazon_2Hz
      * Corazon_2KHz
      * Corazon_3Hz
      * Corazon_4Hz
      * Corazon_5Hz
      * Corazon_7Hz
      * Corazon_DO4
      * Corazon_MI4
      * Corazon_RE4
  * *Motor*
    * *SM-S4303R*
      * MotorBit
  * *Mux*
    * Mux-2-1-flip
    * Mux-2-1
    * Mux-4-1-flip
    * Mux-4-1
  * *Retardo*
    * Tortuga-2
  * *Servos*
    * *Emax-ES08A*
      * ServoBit-90
      * ServoBit
    * *Futaba-3003*
      * Servobit-90
      * Servobit
    * *TowerPro-SG90*
      * Servobit-90
      * Servobit

## Examples
* *0-Soluciones-Tutorial-17*
  * Sol-17-1
  * Sol-17-2
  * Sol-17-3
* *1-Ejemplos*
  * 1-corazon-hz-1
  * 2-corazon-hz-4
  * 3-corazon-seg
  * 4-servobit-1
  * 5-pinza-mecanica
  * 6-motorbit-1
* *2-Ejercicios*
  * Ejercicio-18-1
  * Ejercicio-18-2
  * Ejercicio-18-3


## Authors
* [Juan González-Gómez (Obijuan)](https://github.com/Obijuan)


## License

Licensed under [GPL-2.0](https://opensource.org/licenses/GPL-2.0).

## Coleccion obijuan

Ejercicio 23.1

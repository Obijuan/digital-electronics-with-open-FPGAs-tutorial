## Coleccion vacia

Plantilla para la creacion de colecciones

// Translation document for the collection
// =======================================
// This file contains the texts
// annotated for translation
//
// Instructions:
// 1. Open the PO file with Poedit
// 2. Press "Update" to update from sources

gettext('Bits');
gettext('0');
gettext('Un bit constante a 0');
gettext('1');
gettext('Un bit constante a 1');
gettext('1-Soluciones-Tutorial-Anterior');
gettext('2-Ejemplos-Tutorial-5');
gettext('3-Ejercicios-Tutorial-5');
gettext('ledon');
gettext('Se enciende el <b>LED0</b> de la Icezum Alhambra\nBloque Read-only');
gettext('Ejemplo de imagen metida con HTML\n\n<img src=\"https://github.com/Obijuan/digital-electronics-with-open-FPGAs-tutorial/raw/master/wiki/portada/intro-16.jpg\" WIDTH=200>\n</img>');
